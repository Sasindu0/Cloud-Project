package com.ves.dao;

import com.ves.entity.Test;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class TestDaoImpl implements TestDao{

    @Autowired
    SessionFactory sessionFactory;

    @Override
    public Test get(int id) {
        Session session = sessionFactory.getCurrentSession();

        return session.get(Test.class, id);
    }

    @Override
    public List<Test> getAll() {
        Session session = sessionFactory.getCurrentSession();
        Query<Test> query = session.createQuery("FROM Test", Test.class);

        return query.getResultList();
    }

    @Override
    public void delete(Test test) {
        Session session = sessionFactory.getCurrentSession();
        session.remove(test);
    }

    @Override
    public void saveOrUpdate(Test test) {
        Session session = sessionFactory.getCurrentSession();
        session.saveOrUpdate(test);
    }
}
