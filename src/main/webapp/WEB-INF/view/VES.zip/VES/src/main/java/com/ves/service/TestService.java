package com.ves.service;

import com.ves.entity.Test;

import java.util.List;

public interface TestService {

    Test get(int id);
    List<Test> getAll();
    void delete(Test test);
    void saveOrUpdate(Test test);

}
