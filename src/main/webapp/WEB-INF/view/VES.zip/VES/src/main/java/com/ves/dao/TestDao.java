package com.ves.dao;

import com.ves.entity.Test;

import java.util.List;

public interface TestDao {

    Test get(int id);
    List<Test> getAll();
    void delete(Test test);
    void saveOrUpdate(Test test);

}
