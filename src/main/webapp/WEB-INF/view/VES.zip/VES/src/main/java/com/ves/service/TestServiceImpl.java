package com.ves.service;

import com.ves.dao.TestDao;
import com.ves.entity.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

@Service
public class TestServiceImpl implements TestService{

    @Autowired
    TestDao testDao;

    @Override
    @Transactional
    public Test get(int id) {
        return testDao.get(id);
    }

    @Override
    @Transactional
    public List<Test> getAll() {
        return testDao.getAll();
    }

    @Override
    @Transactional
    public void delete(Test test) {
        testDao.delete(test);
    }

    @Override
    @Transactional
    public void saveOrUpdate(Test test) {
        testDao.saveOrUpdate(test);
    }
}
